package com.grabador.rapido

import android.Manifest
import android.annotation.TargetApi
import android.app.Activity
import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.function.Consumer

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Android 13+: permiso para mostrar la notificación de grabación
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = getString(R.string.instrucciones)
            textSize = 16f
        })
        if (Build.VERSION.SDK_INT >= 33) {
            root.addView(Button(this).apply {
                text = "Añadir botón al panel rápido"
                setOnClickListener { addTile() }
            })
        }
        root.addView(Button(this).apply {
            text = "Probar grabación ahora"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, ProjectionActivity::class.java))
            }
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    @TargetApi(33)
    private fun addTile() {
        val sbm = getSystemService(StatusBarManager::class.java)
        sbm.requestAddTileService(
            ComponentName(this, RecordTile::class.java),
            getString(R.string.tile_label),
            Icon.createWithResource(this, R.drawable.ic_tile),
            mainExecutor,
            Consumer<Int> { result ->
                val msg = when (result) {
                    StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ADDED -> "¡Listo! Baja el panel para verlo"
                    StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ALREADY_ADDED -> "El botón ya estaba en tu panel"
                    else -> "No se agregó. Puedes añadirlo a mano editando el panel ✏️"
                }
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            }
        )
    }
}
