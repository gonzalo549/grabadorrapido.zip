package com.grabador.rapido

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.service.quicksettings.TileService
import android.util.DisplayMetrics
import android.view.WindowManager
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class RecorderService : Service() {

    enum class State { IDLE, COUNTDOWN, RECORDING }

    companion object {
        const val ACTION_START = "com.grabador.rapido.START"
        const val ACTION_STOP = "com.grabador.rapido.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL_ID = "grabacion"
        private const val NOTIF_ID = 1
        private const val COUNTDOWN_SECONDS = 3

        @Volatile var state = State.IDLE
        @Volatile var countdownValue = 0
    }

    private val handler = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var recorder: MediaRecorder? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var videoUri: Uri? = null
    private var pfd: ParcelFileDescriptor? = null
    private var stopping = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_STOP -> stopAll()
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        if (state != State.IDLE) return
        createChannel()
        // Debe ir ANTES de getMediaProjection (obligatorio en Android 14+)
        startForeground(
            NOTIF_ID, buildNotification("Preparando…"),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )

        val code = intent.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)

        if (data == null) { stopAll(); return }

        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { handler.post { stopAll() } }
        }, handler)

        countdown(COUNTDOWN_SECONDS)
    }

    // ---------- Cuenta regresiva ----------
    private fun countdown(n: Int) {
        state = State.COUNTDOWN
        countdownValue = n
        refreshTile()
        updateNotification("La grabación empieza en $n…")
        vibrate(60)
        handler.postDelayed({
            if (state != State.COUNTDOWN) return@postDelayed
            if (n > 1) countdown(n - 1) else startRecording()
        }, 1000)
    }

    // ---------- Grabación ----------
    private fun startRecording() {
        try {
            val (w, h, dpi) = captureSize()

            val name = "Grabacion_" +
                SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_MOVIES + "/GrabadorRapido")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            videoUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            pfd = contentResolver.openFileDescriptor(videoUri!!, "w")

            val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this)
                      else @Suppress("DEPRECATION") MediaRecorder()
            rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            rec.setVideoSize(w, h)
            rec.setVideoFrameRate(30)
            rec.setVideoEncodingBitRate(8_000_000)
            rec.setOutputFile(pfd!!.fileDescriptor)
            rec.prepare()
            recorder = rec

            virtualDisplay = projection!!.createVirtualDisplay(
                "GrabadorRapido", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                rec.surface, null, null
            )
            rec.start()

            state = State.RECORDING
            refreshTile()
            updateNotification("● Grabando — toca el botón del panel para detener")
            vibrate(250)
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo grabar: ${e.message}", Toast.LENGTH_LONG).show()
            stopAll()
        }
    }

    private fun stopAll() {
        if (stopping) return
        stopping = true
        handler.removeCallbacksAndMessages(null)

        var saved = false
        if (state == State.RECORDING) {
            saved = try { recorder?.stop(); true } catch (e: Exception) { false } // falla si fue muy corto
        }
        recorder?.release(); recorder = null
        virtualDisplay?.release(); virtualDisplay = null
        projection?.stop(); projection = null
        pfd?.close(); pfd = null

        videoUri?.let { uri ->
            if (saved) {
                contentResolver.update(uri,
                    ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
                Toast.makeText(this, "Video guardado en Películas/GrabadorRapido",
                    Toast.LENGTH_LONG).show()
            } else {
                contentResolver.delete(uri, null, null)
            }
        }
        videoUri = null

        state = State.IDLE
        refreshTile()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    /** Tamaño de la pantalla, reducido a máx. 1920 px de lado para que cualquier encoder lo acepte. */
    private fun captureSize(): Triple<Int, Int, Int> {
        val wm = getSystemService(WindowManager::class.java)
        val (rw, rh) = if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }
        val scale = min(1f, 1920f / max(rw, rh))
        fun align(x: Int) = ((x * scale).toInt() / 16) * 16
        return Triple(align(rw), align(rh), resources.displayMetrics.densityDpi)
    }

    // ---------- Utilidades ----------
    private fun refreshTile() {
        TileService.requestListeningState(this, ComponentName(this, RecordTile::class.java))
    }

    private fun vibrate(ms: Long) {
        val v: Vibrator = if (Build.VERSION.SDK_INT >= 31)
            getSystemService(VibratorManager::class.java).defaultVibrator
        else @Suppress("DEPRECATION") getSystemService(Vibrator::class.java)
        v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Grabación de pantalla",
                NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(text: String): Notification {
        val stopPi = PendingIntent.getService(
            this, 1,
            Intent(this, RecorderService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_tile)
            .setContentTitle("Grabador Rápido")
            .setContentText(text)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.ic_tile), "Detener", stopPi).build())
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        if (!stopping) stopAll()
        super.onDestroy()
    }
}
