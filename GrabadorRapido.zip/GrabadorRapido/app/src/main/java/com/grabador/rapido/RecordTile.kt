package com.grabador.rapido

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** El botón que aparece al bajar el panel superior. */
class RecordTile : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        if (RecorderService.state != RecorderService.State.IDLE) {
            // Ya está grabando (o contando): detener
            startService(
                Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP)
            )
        } else {
            // Pedir permiso y arrancar (el panel se cierra solo)
            val i = Intent(this, ProjectionActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (Build.VERSION.SDK_INT >= 34) {
                val pi = PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE)
                startActivityAndCollapse(pi)
            } else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(i)
            }
        }
        refresh()
    }

    private fun refresh() {
        val tile = qsTile ?: return
        when (RecorderService.state) {
            RecorderService.State.IDLE -> {
                tile.state = Tile.STATE_INACTIVE
                tile.label = getString(R.string.tile_label)
            }
            RecorderService.State.COUNTDOWN -> {
                tile.state = Tile.STATE_ACTIVE
                tile.label = "Empieza en ${RecorderService.countdownValue}…"
            }
            RecorderService.State.RECORDING -> {
                tile.state = Tile.STATE_ACTIVE
                tile.label = "● Detener"
            }
        }
        tile.updateTile()
    }
}
